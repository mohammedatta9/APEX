
<script src="{{ url('/') }}/cp/assets/js/app.js"></script>
